package com.himanshudadheech.bank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<UserDataAdapter> ListOfuserdataAdapter;
    String HTTP_JSON_URL = "https://himanshu000.000webhostapp.com/bank/upjson.php";
    String s_name_json = "name";
    String s_status_json = "balance";
    String s_email_json = "email";
    String S_account_json ="id";


    ArrayList<String> sNameArrayListForClick;
    ArrayList<String> sEmailArrayListForClick;
    ArrayList<String> sStatusArrayListForClick;
    ArrayList<String> sAccArrayListForClick;

    RecyclerView recyclerView;

    JsonArrayRequest RequestOfJSonArray ;
    RequestQueue requestQueue ;

    View view ;

    int RecyclerViewItemPosition ;

    RecyclerView.LayoutManager layoutManagerOfrecyclerView;

    UserRecyclerViewAdapter recyclerViewadapter;

//for swipe refresh  swipeRefreshLayout

    SwipeRefreshLayout swipeRefreshLayout;

    ImageView ops;
    TextView opstv;
    String userid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
getSupportActionBar().setTitle("Himanshu Payment Bank");
        sNameArrayListForClick = new ArrayList<>();
        sEmailArrayListForClick = new ArrayList<>();
        // facultyContactArrayListForClick= new ArrayList<>();
        sStatusArrayListForClick= new ArrayList<>();
        sAccArrayListForClick= new ArrayList<>();

        ListOfuserdataAdapter = new ArrayList<>();

        recyclerView = (RecyclerView) findViewById(R.id.user_recyclerview);

        recyclerView.setHasFixedSize(true);
        layoutManagerOfrecyclerView = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManagerOfrecyclerView);

        JSON_HTTP_CALL();
        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            GestureDetector gestureDetector = new GestureDetector(MainActivity.this, new GestureDetector.SimpleOnGestureListener() {

                @Override public boolean onSingleTapUp(MotionEvent motionEvent) {

                    return true;
                }

            });
            @Override
            public boolean onInterceptTouchEvent(RecyclerView Recyclerview, MotionEvent motionEvent) {

                view = Recyclerview.findChildViewUnder(motionEvent.getX(), motionEvent.getY());

                if(view != null && gestureDetector.onTouchEvent(motionEvent)) {

                    //Getting RecyclerView Clicked Item value.
                    RecyclerViewItemPosition = Recyclerview.getChildAdapterPosition(view);

                    // Showing RecyclerView Clicked Item value using Toast.
                    // Toast.makeText(faculty_rv_main_Activity.this, facultyNameArrayListForClick.get(RecyclerViewItemPosition), Toast.LENGTH_SHORT).show();
                }

                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView Recyclerview, MotionEvent motionEvent) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                //  requestQueue = Volley.newRequestQueue(notice_general_rv_main_Activity.this);
                ListOfuserdataAdapter.clear();

                requestQueue.add(RequestOfJSonArray);

                recyclerViewadapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    public void JSON_HTTP_CALL(){

        RequestOfJSonArray = new JsonArrayRequest(HTTP_JSON_URL,

                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        ParseJSonResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        requestQueue = Volley.newRequestQueue(MainActivity.this);

        requestQueue.add(RequestOfJSonArray);
    }



    public void ParseJSonResponse(JSONArray array) {



        for (int i = 0; i < array.length(); i++) {

            UserDataAdapter GetDataAdapter2 = new UserDataAdapter();

            JSONObject json = null;


            try {






                json = array.getJSONObject(i);

                GetDataAdapter2.setSname(json.getString(s_name_json));
                sNameArrayListForClick.add(json.getString(s_name_json));

                GetDataAdapter2.setScontact(json.getString(s_status_json));
                sStatusArrayListForClick.add(json.getString(s_status_json));

                GetDataAdapter2.setId(json.getString(S_account_json));
                sAccArrayListForClick.add(json.getString(S_account_json));

                GetDataAdapter2.setSemail(json.getString(s_email_json));
                sEmailArrayListForClick.add(json.getString(s_email_json));


            } catch (JSONException e) {

                e.printStackTrace();
            }


            ListOfuserdataAdapter.add(GetDataAdapter2);
        }
        Collections.reverse(ListOfuserdataAdapter);

        recyclerViewadapter = new UserRecyclerViewAdapter(ListOfuserdataAdapter, MainActivity.this);

        recyclerView.setAdapter(recyclerViewadapter);


    }
}