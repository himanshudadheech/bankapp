package com.himanshudadheech.bank;

public class UserDataAdapter {

    public UserDataAdapter(String sname, String scontact, String semail, String id) {
        this.sname = sname;
        this.scontact = scontact;
        this.semail = semail;
        this.id = id;
    }

    public String sname;
public String id;
    public String  scontact;
    public  String  semail;

    public UserDataAdapter() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getScontact() {
        return scontact;
    }

    public void setScontact(String scontact) {
        this.scontact = scontact;
    }

    public String getSemail() {
        return semail;
    }

    public void setSemail(String semail) {
        this.semail = semail;
    }
}
