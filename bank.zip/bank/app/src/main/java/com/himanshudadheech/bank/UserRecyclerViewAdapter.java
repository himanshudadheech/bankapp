package com.himanshudadheech.bank;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserRecyclerViewAdapter extends RecyclerView.Adapter<UserRecyclerViewAdapter.ViewHolder> implements Filterable {

    Context context;
    List<UserDataAdapter> UserdataAdapters;
    List<UserDataAdapter> UserdataAdaptersFull;


    Bitmap bitmap;

    boolean check = true;

    String FacultyName = "faculty_name";
    String OldFacultyName = "old_faculty_name";

    String FacultyEmail = "faculty_email";
    String OldFacultyEmail = "old_faculty_email";
    String FacultyExperience = "faculty_expirience";
    String OldFacultyExperieince = "old_faculty_expirience";
    String FacultyQualification = "faculty_qualification";
    String OldFacultyQualification = "old_faculty_qualification";
    String FacultySubject = "faculty_subject";
    String OldFacultySubject = "old_faculty_subject";
    String FacultyContact = "faculty_contact";
    String OldFacultyContact = "old_faculty_contact";
    String FacultyDepartment = "faculty_department";
    String OldFacultyDepartment = "old_faculty_department";
    int x;
    int y;

    RequestQueue requestQueue, queue;
    String url = "http://tnjrc.themad.in/appfiles/Userdelete.php"; //ToDo delete url
    String url1 = "https://himanshu000.000webhostapp.com/bank/edit.php"; //ToDo delete url

    public UserRecyclerViewAdapter(List<UserDataAdapter> getUserDataAdapter, Context context) {

        super();
        this.UserdataAdaptersFull = getUserDataAdapter;
        this.context = context;
        this.UserdataAdapters = new ArrayList<>(UserdataAdaptersFull);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_cardview, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder Viewholder, int position) {

        UserDataAdapter UserdataAdapterOBJ = UserdataAdapters.get(position);

//        imageLoader = Image_UserAdapter.getInstance(context).getImageLoader();
//
//        imageLoader.get(UserdataAdapterOBJ.getImageUrl(),
//                ImageLoader.getImageListener(
//                        Viewholder.UserVollyImageView,//Server Image
//                        R.mipmap.ic_launcher,//Before loading server image the default showing image.
//                        android.R.drawable.ic_dialog_alert //Error image if requested image dose not found on server.
//                )
//        );

//        Viewholder.UserVollyImageView.setImageUrl(UserdataAdapterOBJ.getImageUrl(), imageLoader);

        Viewholder.Usernametv.setText(UserdataAdapterOBJ.getSname());
        Viewholder.Useremail.setText(UserdataAdapterOBJ.getSemail());
        Viewholder.Userstatus.setText(UserdataAdapterOBJ.getScontact());
        Viewholder.Useraccount.setText(UserdataAdapterOBJ.getId());





        //image_view_full

        Viewholder.Userrecycler_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, open_deatilfaculty_Activity.class);
                intent.putExtra("faculty_name", UserdataAdapterOBJ.getSname());
                intent.putExtra("faculty_email", UserdataAdapterOBJ.getSemail());
                intent.putExtra("faculty_balance", UserdataAdapterOBJ.getScontact());
                intent.putExtra("faculty_account", UserdataAdapterOBJ.getId());

                context.startActivity(intent);


            }
        });


    }


    @Override
    public int getItemCount() {

        return UserdataAdapters.size();
    }

    @Override
    public Filter getFilter() {
        return newsFilter;
    }

    private final Filter newsFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<UserDataAdapter> filterNewList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filterNewList.addAll(UserdataAdaptersFull);

            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (UserDataAdapter dataAdapter : UserdataAdaptersFull) {

                    if (dataAdapter.getSemail().toLowerCase().contains(filterPattern) || dataAdapter.getSname().toLowerCase().contains(filterPattern))
                        filterNewList.add(dataAdapter);

                }

            }
            FilterResults results = new FilterResults();
            results.values = filterNewList;
            results.count = filterNewList.size();
            return results;

        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            UserdataAdapters.clear();
            UserdataAdapters.addAll((ArrayList) results.values);
            notifyDataSetChanged();

        }
    };


    class ViewHolder extends RecyclerView.ViewHolder {

        // public TextView ImageTitleTextView, ImagePriceTextView, ImageDescriptionTextView;
        public TextView Usernametv, Useremail, Userstatus,Useraccount;
        public NetworkImageView UserVollyImageView;
        public Button delete_btn;
        public Button edit_item_btn;
        public RelativeLayout Userrecycler_card;
        ImageView imageVieww;
        Button updateimageselectdbutton;


        public ViewHolder(View itemView) {

            super(itemView);

            Usernametv = itemView.findViewById(R.id.Categoryusername);
            Useremail = itemView.findViewById(R.id.Categoryemail);
            Userstatus = itemView.findViewById(R.id.Categorystatus);
            Useraccount = itemView.findViewById(R.id.Categoryaccount);

//            UserVollyImageView = (NetworkImageView) itemView.findViewById(R.id.UserVolleyImageView);
           Userrecycler_card = itemView.findViewById(R.id.userrecycler_card);
           // edit_item_btn = itemView.findViewById(R.id.edit_item_btn);
//            //imageVieww = itemView.findViewById(R.id.imagevieww);

        }
    }

//    public void Delete(int item) {
//        UserdataAdapters.remove(item);
//        notifyItemRemoved(item);
//    }

}