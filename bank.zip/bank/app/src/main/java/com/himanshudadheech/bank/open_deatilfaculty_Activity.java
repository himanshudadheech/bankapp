package com.himanshudadheech.bank;


import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class open_deatilfaculty_Activity extends AppCompatActivity {

    List<UserDataAdapter> ListOfUserDataAdapter;
    UserDataAdapter fda;
    RequestQueue requestQueue, queue;


    TextView show_fname_full, show_email_full, show_available,show_account_full;

    String FacultyNamee, FacultyEmaile, Facultybalance,FacultyAcc;

    String url1 = "https://himanshu000.000webhostapp.com/bank/edit.php";


    String FacultyName = "faculty_name";


    String FacultyEmail = "faculty_email";

    String FacultyBal = "faculty_balance";
    String Reciveradd ="reciver_add";
    String ReciverId ="reciver_id";
    String OldFacultyExperieince = "old_faculty_expirience";
    Button check;
    Button submit;
    EditText sendammount;
    EditText reciverid;
    EditText username;
    TextView Total;
    String sendruppe, sendid;

    String name,email,balance;
    int x, y, z;
    String t;
    String sendsettv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_deatilfaculty_);
        getSupportActionBar().setTitle("Account Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        show_fname_full = findViewById(R.id.show_fname_full);
        show_account_full = findViewById(R.id.show_account);
        show_email_full = findViewById(R.id.show_email_full);
        show_available = findViewById(R.id.show_available);

        FacultyNamee = getIntent().getStringExtra("faculty_name");
        FacultyEmaile = getIntent().getStringExtra("faculty_email");
        Facultybalance = getIntent().getStringExtra("faculty_balance");
        FacultyAcc = getIntent().getStringExtra("faculty_account");

        show_fname_full.setText(FacultyNamee);
        show_email_full.setText(FacultyEmaile);
        show_available.setText(Facultybalance);
        show_account_full.setText(FacultyAcc);

        username = findViewById(R.id.nmae);
        username.setText(FacultyNamee);

        name = username.getText().toString();
        email = FacultyEmaile;
        //Amount Sending Process
        //Added to reciver
        sendammount = findViewById(R.id.sendammount);



        reciverid = findViewById(R.id.reciverid);

        submit = findViewById(R.id.send);
        Total = findViewById(R.id.total);

        Total.setVisibility(View.GONE);
        submit.setVisibility(View.GONE);


        check = findViewById(R.id.check);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendruppe = sendammount.getText().toString();
                sendid = reciverid.getText().toString();
                if (sendruppe.isEmpty()) {
                    Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Amount", Toast.LENGTH_SHORT).show();
                }
                else if(sendid.isEmpty()) {
                    Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Account Number", Toast.LENGTH_SHORT).show();
                }else {
                    calculate();
                    //Total.setVisibility(View.VISIBLE);
                    if(z<0 || x==0) {
                        Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Amount greater than 0", Toast.LENGTH_SHORT).show();

                    }
                    else if(x>y ){
                        Toast.makeText(open_deatilfaculty_Activity.this, "Check Account Balance", Toast.LENGTH_SHORT).show();

                    }
                    else{
                        submit.setVisibility(View.VISIBLE);
                        }




                }
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendruppe = sendammount.getText().toString();
                sendid = reciverid.getText().toString();
                if (sendruppe.isEmpty()) {
                    Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Amount", Toast.LENGTH_SHORT).show();
                }
                else if(sendid.isEmpty()) {
                    Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Account Number", Toast.LENGTH_SHORT).show();
                } else {
                    calculate();
                    sendruppe = sendammount.getText().toString();
                    sendid = reciverid.getText().toString();
                    x = Integer.parseInt(sendruppe);
                    //  x = Integer.parseInt(sendruppe);
                    y = Integer.parseInt(Facultybalance);
                    z = y - x;
                    t = String.valueOf(z);
                    Total.setText(t);
                    if(z>=0 && x<=y){
                        send();
                        sendammount.getText().clear();
                        reciverid.getText().clear();
                    }
                    else if(x>y){
                        Toast.makeText(open_deatilfaculty_Activity.this, "Check Account Balance", Toast.LENGTH_SHORT).show();

                    }
                    else{
                        Toast.makeText(open_deatilfaculty_Activity.this, "Please Enter Amount greater than 0", Toast.LENGTH_SHORT).show();
                    }



                }

            }
        });
    }

    public void calculate() {
        sendruppe = sendammount.getText().toString();
        sendid = reciverid.getText().toString();
        x = Integer.parseInt(sendruppe);
        //  x = Integer.parseInt(sendruppe);
        y = Integer.parseInt(Facultybalance);
        z = y - x;
        t = String.valueOf(z);
        Total.setText(t);
    }


    public void send() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(open_deatilfaculty_Activity.this, response, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(open_deatilfaculty_Activity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();


                // String newavailable = Total.getText().toString();

               sendsettv = Total.getText().toString();


                //HashMapParams.put(ImageName, GetImageNameEditText);

                params.put(FacultyName, name);
                params.put(FacultyEmaile, email);
                params.put(FacultyBal, sendsettv);

                //ToDo Revier mai jo add honge
                params.put(Reciveradd,sendruppe);
                params.put(ReciverId,sendid);


                return params;
            }

        };

        queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);

        }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}